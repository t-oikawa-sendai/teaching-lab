@echo off
start /min java -jar "regTester-2.1.0-jar-with-dependencies.jar"
